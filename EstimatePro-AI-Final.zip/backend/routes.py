from fastapi import APIRouter
router = APIRouter()
@router.get('/estimate')
def get_estimate():
    return {'estimate': 'Calculation Logic Here'}