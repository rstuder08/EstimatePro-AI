import psycopg2
# Database connection setup