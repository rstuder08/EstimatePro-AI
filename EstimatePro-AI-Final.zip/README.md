# EstimatePro AI

AI-powered construction estimating tool for contractors.

## Features
- AI-driven blueprint analysis
- Material & labor cost estimation
- Downloadable PDF & Excel reports

## Setup Instructions
1. Clone the repository
2. Install dependencies
3. Run backend & frontend